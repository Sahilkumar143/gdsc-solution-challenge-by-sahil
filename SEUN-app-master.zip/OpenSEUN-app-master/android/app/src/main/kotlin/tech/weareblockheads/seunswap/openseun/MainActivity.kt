package tech.weareblockheads.seunswap.openseun

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
