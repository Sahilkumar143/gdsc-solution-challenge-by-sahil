# OpenSEUN Front-end Application

A platform where communities who decide to use energy saving methods to ensure clean water are rewarded with carbon credits. Built on **[Hedera Hashgraph](https://hedera.com/learning/what-is-hedera-hashgraph "Hedera Hashgraph")**.

-***This is a Flutter/Dart project***

# NOTICE
> This project is in the very early stages of development. We are not accepting pull-requests just yet but will be publishing ***Community Standards and Best Practices*** very soon!
